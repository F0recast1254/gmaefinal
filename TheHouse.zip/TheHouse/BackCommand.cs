﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace TheHouse
{
    public class BackCommand : Command
    {
        public BackCommand() : base()
        {
            this.Name = "back";
        }

        override
        public bool Execute(Player player)
        {
            if (player._rooms.Count != 0)
            {
                player.Back();
            }
            else
            {
                player.WarningMessage("There is nowhere else to go back to...");
            }
            return false;
        }
    }
}
